# Handoff para Claude Code — Neuvo Care Kiosk Bridge

## Objetivo

Dar continuidade ao projeto `neuvo-care-kiosk-bridge`, um bridge local Windows para leitores NFC USB usados no Kiosk do Neuvo Care.

## Caminho local do projeto

```bash
/root/.openclaw/workspace/neuvo-care-kiosk-bridge
```

## Contexto funcional

O frontend do Neuvo Care espera comunicação local via WebSocket:

- URL do app/kiosk: `https://appcare.neuvo.com.br/kiosk`
- WebSocket local esperado: `ws://localhost:8765`
- Status local: `http://localhost:8765/status`
- NFC via USB usando `nfc-pcsc`
- Código aceito: `CARE-XXXXX` direto ou URL contendo `/r/CARE-XXXXX`

Frontend analisado anteriormente:

- Repo: `gabrielfds/neuvo-care-frontend-b2935491`
- Rota: `/kiosk`
- Página: `src/pages/Kiosk.tsx`
- Hook NFC: `src/hooks/useKioskBridge.ts`

## Estado atual do projeto

Pacote Electron baseado no bridge novo do CareID, com:

- Electron tray app
- Single-instance lock
- Auto-launch no Windows
- Auto-update via GitHub Releases
- Logs locais
- Servidor WebSocket local em `8765`
- Leitura NFC via `nfc-pcsc`
- Instalador Windows via `electron-builder` / NSIS

Versão atual em `package.json`:

```json
"version": "0.2.2"
```

Nome do produto:

```json
"productName": "Neuvo Care Kiosk Bridge"
```

App ID:

```json
"appId": "br.com.neuvo.care.kioskbridge"
```

## Arquivos importantes

- `package.json` — scripts, build, versão e metadata do app
- `src/main.js` — processo principal Electron, tray, single instance, janela/kiosk, updater
- `src/bridge.js` — leitura NFC, WebSocket, status e eventos
- `src/bridge-child.js` — processo filho do bridge, se usado pela arquitetura atual
- `assets/icon.svg` — ícone fonte enviado pelo Gabriel
- `assets/icon.png` — ícone raster
- `assets/icon.ico` — ícone Windows configurado no build
- `.github/workflows/neuvo-care-kiosk-bridge-build.yml` — workflow de build/release
- `dist/Neuvo Care Kiosk Bridge Setup 0.2.2.exe` — instalador gerado localmente

## Pendência principal

O repo público de release precisa existir/liberar push:

```text
gabrielfds/neuvo-care-kiosk-bridge-releases
```

Status anterior:

- Token local anterior não permitia criar repo nem fazer push.
- Erro observado: `Resource not accessible by personal access token`.
- Não fazer merge/release sem aprovação do Gabriel.

## O que validar primeiro

Rodar dentro do projeto:

```bash
npm install
node --check src/main.js
node --check src/bridge.js
node --check src/bridge-child.js
npm run dist
```

Se estiver em Linux, o build Windows pode depender de Wine/ambiente disponível. Se falhar por ambiente, reportar claramente.

## Regras operacionais

- Não publicar release/tag sem aprovação explícita do Gabriel.
- Não alterar secrets/tokens.
- Não apagar builds antigos sem pedir.
- Não renomear appId/productName sem avaliar impacto no auto-update e instalação.
- Se mexer no protocolo com o frontend, validar compatibilidade com `useKioskBridge.ts`.

## Próximo passo sugerido para Claude Code

1. Abrir o projeto local.
2. Revisar `README.md`, `package.json`, `src/main.js`, `src/bridge.js` e workflow GitHub.
3. Rodar checks sintáticos.
4. Confirmar se o build local ainda gera instalador.
5. Preparar plano para subir o repo/release quando Gabriel liberar permissão de GitHub.

## Prompt curto para iniciar

> Você está no projeto `/root/.openclaw/workspace/neuvo-care-kiosk-bridge`. Leia `CLAUDE_CODE_HANDOFF.md`, `README.md`, `package.json`, `src/main.js`, `src/bridge.js` e o workflow em `.github/workflows/`. Depois me diga: estado atual, riscos, comandos validados e próximos passos para publicar o instalador Windows sem quebrar auto-update.
