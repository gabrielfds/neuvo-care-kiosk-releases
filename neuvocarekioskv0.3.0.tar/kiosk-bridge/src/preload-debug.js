const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  refresh: async () => ipcRenderer.invoke('debug:getDiagnostics').then((t) => window.dispatchEvent(new CustomEvent('diagnostics', { detail: t }))),
  openLogs: () => ipcRenderer.invoke('debug:openLogs'),
  openKiosk: () => ipcRenderer.invoke('debug:openKiosk'),
  onDiagnostics: (cb) => {
    window.addEventListener('diagnostics', (e) => cb(e.detail));
    ipcRenderer.on('diagnostics', (_event, text) => cb(text));
  }
});
