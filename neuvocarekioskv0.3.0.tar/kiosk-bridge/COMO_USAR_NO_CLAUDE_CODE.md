# Como usar este pacote no Claude Code

Este pacote foi gerado porque o Claude Code não terá acesso ao servidor original.

## Passo 1

Suba/abra esta pasta no ambiente onde o Claude Code consegue trabalhar.

## Passo 2

Peça para ele começar por estes arquivos:

1. `README.md`
2. `CLAUDE_CODE_HANDOFF.md`
3. `package.json`
4. `src/main.js`
5. `src/bridge.js`
6. `src/bridge-child.js`
7. `.github/workflows/neuvo-care-kiosk-bridge-build.yml`

## Prompt sugerido

```text
Você não tem acesso ao servidor original. Trabalhe somente com os arquivos deste pacote.

Leia README.md e CLAUDE_CODE_HANDOFF.md. Depois revise package.json, src/main.js, src/bridge.js, src/bridge-child.js e o workflow GitHub.

Me diga:
1. o que este app faz
2. como ele deve se comportar no Windows
3. riscos técnicos
4. se o workflow está correto para a estrutura atual
5. o que precisa ser ajustado antes de publicar o instalador
6. quais comandos devo rodar para validar

Não publique release, não crie tag e não altere appId/productName sem aprovação do Gabriel.
```

## Observação

O build local `.exe` não foi incluído neste pacote para manter o arquivo leve. O Claude Code deve tratar este pacote como fonte do projeto, não como release final.
