# Neuvo Care Kiosk Bridge

Bridge local para Windows que conecta leitores NFC USB ao Kiosk do Neuvo Care.

Este projeto existe porque navegadores em Windows não acessam leitores NFC USB diretamente de forma confiável. O bridge roda localmente na máquina do cliente, lê a tag NFC via USB e entrega o código lido para o frontend do Kiosk por WebSocket local.

---

## 1. O que este projeto faz

O `Neuvo Care Kiosk Bridge` é um app Electron para Windows que:

1. Inicia junto com o Windows.
2. Fica na bandeja do sistema, perto do relógio.
3. Abre automaticamente o Kiosk do Neuvo Care.
4. Sobe um servidor local em `127.0.0.1:8765`.
5. Escuta leitores NFC USB compatíveis via `nfc-pcsc`.
6. Lê tags NFC e extrai um código do tipo `CARE-XXXXX`.
7. Envia o código para o frontend via WebSocket em `ws://localhost:8765`.
8. Expõe status local em `http://localhost:8765/status`.
9. Impede múltiplas instâncias do app para evitar conflito de porta/leitor.

---

## 2. Contexto do produto

Frontend esperado:

- App/Kiosk: `https://appcare.neuvo.com.br/kiosk`
- WebSocket local: `ws://localhost:8765`
- Status local: `http://localhost:8765/status`

Frontend analisado anteriormente:

- Repo: `gabrielfds/neuvo-care-frontend-b2935491`
- Rota: `/kiosk`
- Página: `src/pages/Kiosk.tsx`
- Hook NFC: `src/hooks/useKioskBridge.ts`

O frontend deve tentar conectar no bridge local. Quando o bridge envia um evento NFC, o Kiosk recebe o payload e processa o código.

---

## 3. Como deve se comportar no cliente

### Ao abrir o Windows

- O app deve iniciar automaticamente.
- Deve aparecer apenas na tray/bandeja do Windows.
- Deve subir o servidor local na porta `8765`.
- Deve abrir o Kiosk em:

```text
https://appcare.neuvo.com.br/kiosk
```

### Quando o leitor NFC está conectado

- O menu da tray deve indicar que o leitor foi detectado.
- O status local deve retornar algo próximo de:

```json
{
  "ok": true,
  "readerConnected": true,
  "readerName": "nome do leitor",
  "clients": 1
}
```

### Quando uma tag é aproximada

O bridge deve:

1. Ler UID/ATR da tag.
2. Tentar ler conteúdo NTAG/NDEF bruto.
3. Extrair um código válido.
4. Aplicar debounce para evitar leitura duplicada.
5. Enviar evento para todos os clientes WebSocket conectados.

Evento esperado:

```json
{
  "type": "nfc_read",
  "payload": "CARE-XXXXX",
  "reader": "nome do leitor",
  "uid": "UID_DA_TAG",
  "timestamp": "2026-07-13T00:00:00.000Z"
}
```

### Quando o leitor é removido

O bridge deve enviar status indicando leitor desconectado:

```json
{
  "type": "bridge_status",
  "readerConnected": false,
  "reader": null,
  "timestamp": "2026-07-13T00:00:00.000Z"
}
```

### Quando o app é aberto duas vezes

Não pode criar outra instância funcional.

Comportamento esperado:

- Segunda abertura não cria novo servidor.
- Segunda abertura não disputa o leitor NFC.
- Segunda abertura não abre outro processo funcional.
- A instância existente permanece ativa.
- O log registra tentativa de segunda instância.

---

## 4. Como foi feito

A base foi reaproveitada do bridge novo do CareID, adaptada para o Neuvo Care.

Principais decisões técnicas:

- `Electron` para empacotar como app Windows com tray.
- `nfc-pcsc` para leitura de leitores NFC USB/PCSC.
- `ws` para WebSocket local.
- `electron-log` para logs locais.
- `auto-launch` para iniciar com o Windows.
- `electron-builder` para gerar instalador NSIS.
- `app.requestSingleInstanceLock()` para impedir múltiplas instâncias.
- Processo filho separado para o bridge NFC, reduzindo risco de travar o processo principal Electron.

---

## 5. Arquitetura

```text
Windows
└── Neuvo Care Kiosk Bridge.exe
    ├── Processo principal Electron
    │   ├── Tray/menu
    │   ├── Auto-launch
    │   ├── Single-instance lock
    │   ├── Abre o Kiosk no navegador
    │   └── Gerencia processo filho
    │
    └── Processo filho bridge-child.js
        └── bridge.js
            ├── HTTP local /status
            ├── WebSocket local ws://localhost:8765
            ├── NFC via nfc-pcsc
            ├── Extração de CARE-XXXXX
            └── Debounce de leituras duplicadas
```

---

## 6. Arquivos principais

### `package.json`

Define:

- Nome do pacote: `neuvo-care-kiosk-bridge`
- Versão atual: `0.2.2`
- Produto Windows: `Neuvo Care Kiosk Bridge`
- App ID: `br.com.neuvo.care.kioskbridge`
- Scripts de build/release
- Configuração do `electron-builder`
- Ícone Windows em `assets/icon.ico`

### `src/main.js`

Processo principal Electron.

Responsabilidades:

- Criar app de tray.
- Impedir múltiplas instâncias.
- Abrir o Kiosk.
- Criar menu contextual.
- Abrir status local.
- Abrir pasta de logs.
- Iniciar/reiniciar processo filho.
- Configurar auto-launch.
- Matar processo filho ao sair.

Constantes importantes:

```js
const APP_NAME = 'Neuvo Care Kiosk Bridge';
const KIOSK_URL = process.env.NEUVO_CARE_KIOSK_URL || 'https://appcare.neuvo.com.br/kiosk';
const PORT = 8765;
```

### `src/bridge.js`

Núcleo do bridge.

Responsabilidades:

- Criar servidor HTTP local.
- Criar WebSocketServer.
- Expor `GET /status`.
- Detectar leitor NFC.
- Ler cartão/tag.
- Extrair payload.
- Enviar eventos para clientes conectados.

Porta padrão:

```text
127.0.0.1:8765
```

Variáveis suportadas:

```text
NEUVO_CARE_BRIDGE_PORT=8765
NEUVO_CARE_DUPLICATE_WINDOW_MS=2000
```

### `src/bridge-child.js`

Wrapper do processo filho.

Responsabilidades:

- Iniciar `bridge.js`.
- Enviar status para o processo principal via IPC.
- Reportar logs, erros e estado.
- Encerrar processo em erro não tratado.

### `assets/`

Contém os ícones do aplicativo:

- `icon.svg` — fonte do ícone.
- `icon.png` — ícone raster.
- `icon.ico` — ícone Windows usado no build.
- `tray.png` / `tray-16.png` — assets de bandeja, se usados.

### `dist/`

Contém build local já gerado:

- `Neuvo Care Kiosk Bridge Setup 0.2.2.exe`
- `Neuvo Care Kiosk Bridge Setup 0.2.2.exe.blockmap`
- `win-unpacked/Neuvo Care Kiosk Bridge.exe`

Atenção: `dist/` é artefato de build. Não tratar como fonte principal.

### `.github/workflows/neuvo-care-kiosk-bridge-build.yml`

Workflow de build Windows.

Estado atual importante:

- Usa `windows-latest`.
- Instala Node 20.
- Instala Python 3.11 para `node-gyp`.
- Instala ImageMagick.
- Gera `assets/icon.png` e `assets/icon.ico` a partir do SVG.
- Roda `npm install`.
- Roda `npm run dist`.
- Sobe artefatos do instalador.

Risco: o workflow atual assume `working-directory: kiosk-bridge` e paths `kiosk-bridge/**`. Se o repo final tiver este projeto na raiz, ajustar o workflow antes de publicar.

---

## 7. Protocolo com o frontend

### Conexão

Frontend conecta em:

```text
ws://localhost:8765
```

Ao conectar, o bridge envia status inicial:

```json
{
  "type": "bridge_status",
  "readerConnected": true,
  "reader": "nome do leitor",
  "timestamp": "2026-07-13T00:00:00.000Z"
}
```

### Evento de leitura NFC

```json
{
  "type": "nfc_read",
  "payload": "CARE-XXXXX",
  "reader": "nome do leitor",
  "uid": "UID_DA_TAG",
  "timestamp": "2026-07-13T00:00:00.000Z"
}
```

### Status local

```http
GET http://localhost:8765/status
```

Resposta:

```json
{
  "ok": true,
  "readerConnected": true,
  "readerName": "nome do leitor",
  "clients": 1
}
```

---

## 8. Leitura e extração do código

O bridge aceita:

1. Código direto:

```text
CARE-12345
```

2. URL contendo `/r/CARE-12345`:

```text
https://appcare.neuvo.com.br/r/CARE-12345
```

3. Fallback para UID/ATR quando não consegue ler payload textual.

A extração atual tenta encontrar:

- `CARE-XXXXX`
- URL `http(s)://...`
- UID como fallback

A função principal é `extractLikelyCode()` em `src/bridge.js`.

---

## 9. Debounce de leitura duplicada

Há debounce para evitar múltiplos eventos quase simultâneos da mesma tag.

Configuração padrão:

```text
NEUVO_CARE_DUPLICATE_WINDOW_MS=2000
```

Comportamento:

- Se `uid + payload` forem iguais dentro da janela de 2 segundos, ignora a leitura duplicada.
- Isso reduz eventos duplicados causados por leitores como ACR122U ou múltiplas detecções rápidas.

---

## 10. Menu da tray

O app exibe menu com:

- Status do bridge.
- Quantidade de clientes web conectados.
- PID do processo bridge.
- Abrir Kiosk Neuvo Care.
- Abrir status local.
- Abrir pasta de logs.
- Reiniciar Bridge.
- Sair.

O clique no ícone da tray também tenta abrir o Kiosk.

---

## 11. Logs

Logs são feitos com `electron-log`.

O caminho real varia conforme Windows/usuário, mas pode ser aberto pelo menu:

```text
Abrir pasta de logs
```

Logs importantes esperados:

- Inicialização do processo filho.
- Leitor conectado.
- Erros de leitura NFC.
- Falha ao iniciar bridge.
- Segunda instância detectada.

---

## 12. Comandos de desenvolvimento

Instalar dependências:

```bash
npm install
```

Rodar em desenvolvimento:

```bash
npm start
```

Validar sintaxe:

```bash
node --check src/main.js
node --check src/bridge.js
node --check src/bridge-child.js
```

Gerar instalador Windows sem publicar:

```bash
npm run dist
```

Gerar build com publicação configurada:

```bash
npm run release
```

Atenção: não rodar release/publicação sem aprovação explícita do Gabriel.

---

## 13. Build Windows

Build configurado via `electron-builder`.

Configuração relevante:

```json
"win": {
  "target": "nsis",
  "publisherName": "Neuvo",
  "icon": "assets/icon.ico"
}
```

NSIS:

```json
"nsis": {
  "oneClick": false,
  "allowToChangeInstallationDirectory": false,
  "perMachine": false,
  "createDesktopShortcut": true,
  "createStartMenuShortcut": true,
  "shortcutName": "Neuvo Care Kiosk Bridge",
  "runAfterFinish": true
}
```

O app é instalado por usuário, não por máquina.

---

## 14. Release e GitHub

Repo de release planejado:

```text
gabrielfds/neuvo-care-kiosk-bridge-releases
```

Pendência histórica:

- Token anterior não permitia criar repo nem fazer push.
- Erro observado: `Resource not accessible by personal access token`.

Antes de publicar:

1. Confirmar se o repo existe.
2. Confirmar se o token/conta tem permissão de push/release.
3. Confirmar estrutura esperada do repo:
   - projeto na raiz; ou
   - projeto dentro de `kiosk-bridge/`.
4. Ajustar workflow conforme a estrutura real.
5. Validar build local.
6. Só então criar tag/release.

Não criar tag nem release sem aprovação do Gabriel.

---

## 15. Pontos de atenção para Claude Code

### 15.1 Estrutura do workflow

O workflow atual está configurado para projeto dentro de `kiosk-bridge/`:

```yaml
defaults:
  run:
    working-directory: kiosk-bridge
```

Mas o projeto local atual está em:

```text
/root/.openclaw/workspace/neuvo-care-kiosk-bridge
```

Se este diretório virar a raiz do repo, o workflow deve ser ajustado.

### 15.2 Auto-update

O projeto usa `electron-updater`, mas `package.json` ainda precisa ser revisado para garantir que `publish` esteja corretamente configurado para o repo final.

Sem `publish` correto, o build pode funcionar, mas o auto-update não vai encontrar releases.

### 15.3 Dependência nativa `nfc-pcsc`

`nfc-pcsc` pode exigir ambiente correto no Windows:

- Node-gyp.
- Python.
- Build tools.
- PC/SC service ativo.
- Driver do leitor NFC instalado.

O workflow já instala Python, mas validar build real no GitHub Actions.

### 15.4 Leitores NFC

Testar especialmente com:

- ACR122U.
- Leitores PCSC compatíveis.

O ACR122U pode gerar leituras fantasma/duplicadas em alguns cenários. O debounce já existe para reduzir esse risco.

### 15.5 Múltiplas instâncias

Não remover `app.requestSingleInstanceLock()`.

Esse ponto foi incluído por problema real observado em cliente no bridge do CareID.

### 15.6 Porta fixa

A porta `8765` é contrato com o frontend.

Não alterar sem ajustar `useKioskBridge.ts` no frontend.

---

## 16. Checklist mínimo antes de entregar

- [ ] `npm install` executado sem erro crítico.
- [ ] `node --check src/main.js` OK.
- [ ] `node --check src/bridge.js` OK.
- [ ] `node --check src/bridge-child.js` OK.
- [ ] `npm run dist` gera instalador.
- [ ] Instalador abre no Windows.
- [ ] App aparece na tray.
- [ ] `http://localhost:8765/status` responde.
- [ ] Frontend conecta em `ws://localhost:8765`.
- [ ] Leitor NFC é detectado.
- [ ] Tag com `CARE-XXXXX` dispara `nfc_read`.
- [ ] Segunda abertura não cria outra instância funcional.
- [ ] Logs estão acessíveis pelo menu.

---

## 17. O que não fazer sem aprovação

- Não publicar release.
- Não criar tag.
- Não alterar `appId`.
- Não alterar `productName`.
- Não mudar porta `8765`.
- Não mexer no contrato WebSocket sem alinhar com o frontend.
- Não apagar `dist/` antigo se ele estiver sendo usado como evidência/build local.
- Não alterar secrets/tokens.

---

## 18. Próximo passo recomendado

Para Claude Code:

1. Ler este README inteiro.
2. Ler `CLAUDE_CODE_HANDOFF.md`.
3. Revisar `package.json`, `src/main.js`, `src/bridge.js`, `src/bridge-child.js` e workflow.
4. Rodar validações sintáticas.
5. Verificar se o workflow precisa mudar de `kiosk-bridge/` para raiz.
6. Confirmar configuração de `publish` do `electron-builder`.
7. Preparar PR ou pacote final, mas não publicar release sem aprovação.

Prompt útil:

```text
Leia o README.md e CLAUDE_CODE_HANDOFF.md deste projeto. Depois valide o estado atual do Neuvo Care Kiosk Bridge, confira se o workflow bate com a estrutura real do repo, revise o auto-update/electron-builder e me diga exatamente o que precisa ser ajustado antes de publicar o instalador Windows.
```
